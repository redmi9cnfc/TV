#!/system/bin/sh
PACKAGE="${PACKAGE:-ru.oneme.app}"
SHORT_SLEEP="${SHORT_SLEEP:-1}"
LONG_SLEEP="${LONG_SLEEP:-5}"
INITIAL_DELAY="${INITIAL_DELAY:-10}"
LOG_TAG="[oneme-killer]"

log() {
  if command -v date >/dev/null 2>&1; then
    echo "$(date '+%F %T') ${LOG_TAG} $*"
  else
    echo "${LOG_TAG} $*"
  fi
}

_graceful_exit() {
  log "Received stop signal, exiting."
  exit 0
}
trap _graceful_exit INT TERM

sleep "$INITIAL_DELAY"
log "Service started for package: $PACKAGE"

while true; do
  if command -v pidof >/dev/null 2>&1; then
    pids="$(pidof "$PACKAGE" 2>/dev/null || true)"
  else
    pids="$(ps -A 2>/dev/null | awk -v pkg="$PACKAGE" '$0~pkg {print $2}' || true)"
  fi

  if [ -n "$pids" ]; then
    log "Found pids: $pids — attempting to stop"
    if command -v am >/dev/null 2>&1; then
      am force-stop "$PACKAGE" 2>/dev/null || true
    fi
    for pid in $pids; do
      if kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
        sleep 0.5
      fi
      if kill -0 "$pid" 2>/dev/null; then
        kill -9 "$pid" 2>/dev/null || true
      fi
    done
    sleep "$SHORT_SLEEP"
  else
    sleep "$LONG_SLEEP"
  fi
done
