
sleep 10

PACKAGE="ru.oneme.app"
SLEEP=1

log "Service started for package: $PACKAGE"

while true; do

  pid=$(pidof "$PACKAGE" 2>/dev/null)
  if [ -n "$pid" ]; then
    log "Found $PACKAGE pid: $pid — killing"  
    for p in $pid; do
      kill -9 "$p" 2>/dev/null
    done
  fi
  sleep "$SLEEP"
done
